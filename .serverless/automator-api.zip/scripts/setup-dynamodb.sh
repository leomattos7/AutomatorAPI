#!/bin/bash

# Carrega variáveis de ambiente
if [ -f .env ]; then
    export $(cat .env | grep -v '#' | awk '/=/ {print $1}')
fi

# Verifica se as credenciais AWS estão configuradas
if [ -z "$AWS_ACCESS_KEY_ID" ] || [ -z "$AWS_SECRET_ACCESS_KEY" ]; then
    echo "Error: AWS credentials not found. Please set AWS_ACCESS_KEY_ID and AWS_SECRET_ACCESS_KEY in .env file"
    exit 1
fi

# Define a região como us-east-1
AWS_REGION=us-east-1

echo "Creating DynamoDB tables in region $AWS_REGION..."

# Cria tabela Users com índice secundário para email
echo "Creating Users table..."
aws dynamodb create-table \
    --table-name Users \
    --attribute-definitions \
        AttributeName=id,AttributeType=S \
        AttributeName=email,AttributeType=S \
    --key-schema \
        AttributeName=id,KeyType=HASH \
    --global-secondary-indexes \
        "[{\"IndexName\": \"EmailIndex\",\"KeySchema\": [{\"AttributeName\":\"email\",\"KeyType\":\"HASH\"}],\"Projection\":{\"ProjectionType\":\"ALL\"},\"ProvisionedThroughput\": {\"ReadCapacityUnits\": 5, \"WriteCapacityUnits\": 5}}]" \
    --provisioned-throughput \
        ReadCapacityUnits=5,WriteCapacityUnits=5 \
    --region $AWS_REGION

# Cria tabela Goals
echo "Creating Goals table..."
aws dynamodb create-table \
    --table-name Goals \
    --attribute-definitions \
        AttributeName=userId,AttributeType=S \
        AttributeName=goalId,AttributeType=S \
    --key-schema \
        AttributeName=userId,KeyType=HASH \
        AttributeName=goalId,KeyType=RANGE \
    --provisioned-throughput \
        ReadCapacityUnits=5,WriteCapacityUnits=5 \
    --region $AWS_REGION

# Cria tabela Sessions
echo "Creating Sessions table..."
aws dynamodb create-table \
    --table-name Sessions \
    --attribute-definitions \
        AttributeName=token,AttributeType=S \
    --key-schema \
        AttributeName=token,KeyType=HASH \
    --provisioned-throughput \
        ReadCapacityUnits=5,WriteCapacityUnits=5 \
    --region $AWS_REGION

echo "Waiting for tables to be created..."
aws dynamodb wait table-exists --table-name Users --region $AWS_REGION
aws dynamodb wait table-exists --table-name Goals --region $AWS_REGION
aws dynamodb wait table-exists --table-name Sessions --region $AWS_REGION

echo "All tables created successfully!"

# Lista as tabelas criadas
echo "Listing tables:"
aws dynamodb list-tables --region $AWS_REGION
